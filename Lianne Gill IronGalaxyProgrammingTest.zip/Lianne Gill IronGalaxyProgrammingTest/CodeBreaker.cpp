// Instructions
// 
// Implement a code breaking game as a console application. At the beginning of the game, it randomly generates a secret 4 digit code.
// Each digit should be unique. For example, 0123 and 3217 are valid codes, but 0112 and 7313 are not.
//
// Once the number has been generated, the player has 8 chances to guess the code. After each guess, the game should report how many digits
// they guessed correctly, and how many had the right number, but in the wrong place. For example, with a secret code of 0123, a guess of 0451
// has one digit correct (the 0), and one digit with the right number in the wrong place (the 1).
// 
// After the player has either correctly broken the code or run out of guesses, ask if they would like to play again. If so, generate a new
// code and start again, otherwise exit the program.
//
// All code should go in this file. While we do not expect exhaustive error handling, we do expect that your game will handle unexpected inputs without crashing.
//
// Good luck!
#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <string>
using namespace std;

//For changing # of Digits of code and guess
#define DIGITS 4;
//For changing number of allowed guesses by user
#define GUESSES 8;

class CodeBreaker{
	public:
		int digits = DIGITS;
		
		CodeBreaker(){start();};
		~CodeBreaker(){reset();};
		
		void guessCode(string guess){
			int correct = 0, incorrect = 0;
			if (num_guesses > 0) {
				//Compare guessed number to code
				for (int i = 0; i < digits; ++i) {
					//Check if guessed digit in code
					if (code.count(guess[i]) > 0) {
						for (auto it = code[guess[i]].begin(); it < code[guess[i]].end(); ++it) {
							//Iterate through digit vector to see if guessed digit position matches code digit position
							if (*it == i) {
								correct++;
								break;
							}
							//Else guessed digit exits in code but not in any corret postion
							else if (it == prev(code[guess[i]].end())) {
								incorrect++;
								break;
							} 
							else {
								continue;
							}
						}
					}
				}

				std::cout << "You have guessed " << correct + incorrect << " numbers correctly and " << correct << 
					" were in the right place and " << incorrect << " were in the wrong place" << std::endl;
				num_guesses--;
			}
			//If user is out of guesses or has guessed the correct code
			if (num_guesses == 0 || correct == digits) {
				reset();
				if (correct == digits)
					std::cout << "Congrats you broke the code! Would you like to play again? y/n" << std::endl;
				else
					std::cout << "You have ran out of guesses, would you like to try again? y/n: " << std::endl;
				
				string s;
				while (1){
					std::cin >> s;
					if (s == "y" || s == "Y") {
						start();
						break;
					}
					else if (s == "n" || s == "N") {
						exit(0);
					}
					else {
						std::cout << "Incorrect input please select y or n: " << std::endl;
					}
				}
			}
			return;
		};
	
	protected:
		void start() {
			//Insert Digits into map for quick look up
			//add position to vector for comparison if
			//more then one of the same digit exist in code.
			for (int i = 0; i < digits; ++i) {
				int random = rand() % 10;
				char c = '0' + random;
				code[c].push_back(i);
			}
			num_guesses = GUESSES;
		};
		void reset(){
			code.clear();
		};
	
	private:
		//map contianing code to be broken
		std::unordered_map<char, std::vector<int>> code;
		//number of guesses
		int num_guesses;
};

int main()
{
	string guess;
	CodeBreaker codeBreaker;
	while (1) {
		std::cout << "Input a " << codeBreaker.digits << " digit number to guess code or enter x to exit: ";
		std::cin >>  guess;
		//Exit Game
		if (guess == "x" || guess == "X") {
			exit(0);
		}
		//Check input contains soley numbers.
		else if(!(std::all_of(guess.begin(), guess.end(), ::isdigit))) {
			std::cout << "Guess must contain only numbers." << std::endl;
			cin.clear();
			cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
		}
		//Check # of guess digits matched # of code digits if not return.
		else if (guess.length() != codeBreaker.digits) {
			std::cout << "You have provide the incorrect number of digits." << std::endl;
		}
		else {
			codeBreaker.guessCode(guess);
		}
	}
    return 0;
}
// This was a great challenge!
// Thank you for your time and considerations.